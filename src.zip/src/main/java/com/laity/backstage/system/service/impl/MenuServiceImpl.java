package com.laity.backstage.system.service.impl;

import com.laity.backstage.system.entity.Menu;
import com.laity.backstage.system.service.MenuService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author D.F Douglas
 * @version 1.0.0
 * @ClassName MenuServiceImpl
 * @Description TODO
 * @createTime 2019/6/7/18:39
 */
@Service
public class MenuServiceImpl implements MenuService {
    @Override
    public List<Menu> lodUserMenu(Map<String, Object> map) {
        return null;
    }

    @Override
    public List<Menu> queryAll() {
        return null;
    }
}
