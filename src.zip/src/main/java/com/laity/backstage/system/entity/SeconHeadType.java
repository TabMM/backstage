package com.laity.backstage.system.entity;

import java.io.Serializable;

public class SeconHeadType implements Serializable {
    private String secheadType;

    private String secheadName;

    private static final long serialVersionUID = 1L;

    public String getSecheadType() {
        return secheadType;
    }

    public void setSecheadType(String secheadType) {
        this.secheadType = secheadType;
    }

    public String getSecheadName() {
        return secheadName;
    }

    public void setSecheadName(String secheadName) {
        this.secheadName = secheadName;
    }
}