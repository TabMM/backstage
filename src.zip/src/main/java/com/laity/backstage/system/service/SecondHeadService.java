package com.laity.backstage.system.service;

import com.laity.backstage.system.entity.SeconHead;

import java.util.List;
import java.util.Map;

public interface SecondHeadService {

    List<Map<String, Object>> getSecList();

    /**
     * @return java.lang.String
     * @Author 审核通过
     * @Description //TODO
     * @Date 11:52 2019/6/15
     * @Param [seconHead]
     **/
    String agree(SeconHead seconHead);

    /**
     * @return java.lang.String
     * @Author 添加
     * @Description //TODO
     * @Date 12:19 2019/6/15
     * @Param [seconHead]
     **/
    String add(SeconHead seconHead);

    /**
     * @return java.lang.String
     * @Author 驳回
     * @Description //TODO
     * @Date 14:44 2019/6/15
     * @Param [seconHead]
     **/
    String notAgree(SeconHead seconHead);

    /**
     * @return java.lang.String
     * @Author 删除
     * @Description //TODO
     * @Date 15:41 2019/6/15
     * @Param [seconHead]
     **/
    String deleteData(SeconHead seconHead);

    /**
     * @return java.lang.String
     * @Author 查询详情
     * @Description //TODO
     * @Date 15:56 2019/6/15
     * @Param [seconHead]
     **/


    List<Map<String, Object>> schoolSecondHead(SeconHead seconHead);

    /**
     * @return java.lang.String
     * @Author 更新数据
     * @Description //TODO
     * @Date 16:37 2019/6/15
     * @Param [seconHead]
     **/
    String updateSchoolById(SeconHead seconHead);

    /**
     * @return java.util.List<java.util.Map < java.lang.String, java.lang.Object>>
     * @Author 根据类型分析数据
     * @Description //TODO
     * @Date 17:06 2019/6/15
     * @Param []
     **/
    List<Map<String, Object>> anlyze();
}
