package com.laity.backstage.system.service.impl;

import com.laity.backstage.system.dao.SeconHeadMapper;
import com.laity.backstage.system.dao.SeconHeadTypeMapper;
import com.laity.backstage.system.entity.SeconHead;
import com.laity.backstage.system.service.SecondHeadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author D.F Douglas
 * @version 1.0.0
 * @ClassName SecondHeadServiceImpl
 * @Description TODO
 * @createTime 2019/6/15/10:56
 */
@Service
public class SecondHeadServiceImpl implements SecondHeadService {

    @Autowired
    SeconHeadMapper seconHeadMapper;

    @Override
    public List<Map<String ,Object>> getSecList() {
        List<Map<String ,Object>> list=seconHeadMapper.getSecList();
            return list;

    }

    @Override
    public String agree(SeconHead seconHead) {
      String n=  seconHeadMapper.agree(seconHead);
      System.out.println(n);

        return n;
    }

    @Override
    public String add(SeconHead seconHead) {
        String n= null;
        try {
            seconHeadMapper.insertSelective(seconHead);
            n="1";
        } catch (Exception e) {
            e.printStackTrace();
            n="0";
        }
        return n;
    }

    @Override
    public String notAgree(SeconHead seconHead) {
        String n=  seconHeadMapper.notAgree(seconHead);
        System.out.println(n);

        return n;
    }

    @Override
    public String deleteData(SeconHead seconHead) {
        String n=  seconHeadMapper.deleteData(seconHead);
        System.out.println(n);

        return n;
    }

    @Override
    public List<Map<String, Object>> schoolSecondHead(SeconHead seconHead) {
        List<Map<String ,Object>> list=seconHeadMapper.schoolSecondHead(seconHead);
        return list;

    }

    @Override
    public String updateSchoolById(SeconHead seconHead) {

      //  System.out.println(n);
        String n= null;
        try {
            seconHeadMapper.updateSchoolById(seconHead);
            n="1";
        } catch (Exception e) {
            e.printStackTrace();
            n="0";
        }
        return n;


    }

    @Override
    public List<Map<String, Object>> anlyze() {
        List<Map<String ,Object>> list=seconHeadMapper.anlyze();
        return list;
    }
}
