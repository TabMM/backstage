package com.laity.backstage.system.dao;

import com.laity.backstage.system.entity.SeconHeadType;

public interface SeconHeadTypeMapper {
    int insert(SeconHeadType record);

    int insertSelective(SeconHeadType record);
}