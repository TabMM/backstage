package com.laity.backstage.system.entity;

import java.io.Serializable;
import java.util.Date;

public class SeconHead implements Serializable {
    private String secheadid;

    private String secheadType;

    private String secheadTitle;

    private String secheadDescrib;

    private String secheadPrice;

    private Date createTime;

    private Date editeTime;

    private String isNote;

    private String flag;

    private String lxdh;

    private String name;

    private String xykh;

    private String item1;

    private String item2;

    private static final long serialVersionUID = 1L;

    public String getSecheadid() {
        return secheadid;
    }

    public void setSecheadid(String secheadid) {
        this.secheadid = secheadid;
    }

    public String getSecheadType() {
        return secheadType;
    }

    public void setSecheadType(String secheadType) {
        this.secheadType = secheadType;
    }

    public String getSecheadTitle() {
        return secheadTitle;
    }

    public void setSecheadTitle(String secheadTitle) {
        this.secheadTitle = secheadTitle;
    }

    public String getSecheadDescrib() {
        return secheadDescrib;
    }

    public void setSecheadDescrib(String secheadDescrib) {
        this.secheadDescrib = secheadDescrib;
    }

    public String getSecheadPrice() {
        return secheadPrice;
    }

    public void setSecheadPrice(String secheadPrice) {
        this.secheadPrice = secheadPrice;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getEditeTime() {
        return editeTime;
    }

    public void setEditeTime(Date editeTime) {
        this.editeTime = editeTime;
    }

    public String getIsNote() {
        return isNote;
    }

    public void setIsNote(String isNote) {
        this.isNote = isNote;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getLxdh() {
        return lxdh;
    }

    public void setLxdh(String lxdh) {
        this.lxdh = lxdh;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getXykh() {
        return xykh;
    }

    public void setXykh(String xykh) {
        this.xykh = xykh;
    }

    public String getItem1() {
        return item1;
    }

    public void setItem1(String item1) {
        this.item1 = item1;
    }

    public String getItem2() {
        return item2;
    }

    public void setItem2(String item2) {
        this.item2 = item2;
    }
}